BLCC COA 3 AI Recommendation Popup

File: App_Final_COA3_Recommendation_Popup.tsx

Implementation:
- Selecting COA 3 opens a modal recommendation pop-up.
- The recommendation uses the existing transparent rule-based aiSupport logic and current scenario values.
- It shows current blood/evacuation demand, blood pool, communications, cold-chain status, disruption level, and recent applied actions from the current round.
- After a COA 3 action is resolved, the recommendation pop-up reopens with updated state and decision history.
- A “View COA 3 AI recommendation” button reopens the panel at any time while COA 3 is selected.
- The redundant persistent inline AI panel was removed. The After-action review remains unchanged.

How to use:
1. Make a backup of your current App.tsx.
2. Replace the contents of App.tsx with the contents of App_Final_COA3_Recommendation_Popup.tsx (or rename this file to App.tsx).
3. Keep your existing style.css and other project files.
4. Run the project/build and test COA 1, COA 2, and COA 3.

Important: Recommendations are transparent rule-based training logic using synthetic scenario data, not a connected live AI model or validated clinical guidance.
